<form action="recievers/post_reciever.php" method="POST">
    <label>Name</label>
    <input type="text" name="name" />

    <label>Age</label>
    <input type="number" name="age" />

    <input type="submit">
</form>