<?php

// echo $_SERVER['PHP_SELF'];
// echo $_SERVER['REQUEST_METHOD'];


echo "<pre>";
    print_r($_SERVER);
echo "</pre>";