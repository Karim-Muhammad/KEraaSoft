<?php

echo "<pre>";
    print_r($_GET);
echo "</pre>";

echo "hello my name is {$_GET['name']} <br> and my age is {$_GET['age']}";