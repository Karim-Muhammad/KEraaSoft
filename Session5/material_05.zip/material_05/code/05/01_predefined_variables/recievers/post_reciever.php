<?php


if($_SERVER['REQUEST_METHOD'] == 'POST') {

    echo 'hello ' . $_POST['name'];
} else {

    echo "emshy yala";
}

// echo "<pre>";
//     print_r($_POST);
// echo "</pre>";

// echo $_POST['name'];

// echo $_GET['name'];     // error