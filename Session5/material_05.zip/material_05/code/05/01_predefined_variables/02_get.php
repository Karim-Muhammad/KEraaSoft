<?php

$name = 'ahmed';
$age = 20;

?>

<a href="recievers/request_receiver.php?name=<?= $name ?>&age=<?= $age ?>">Send to get receiver</a>
