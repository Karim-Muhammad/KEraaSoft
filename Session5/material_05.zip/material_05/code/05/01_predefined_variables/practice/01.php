<?php

    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];

        echo "The summation is " . $num1 + $num2;
    }
    

?>


<form action="" method="POST">
    <label>Number 1</label>
    <input type="text" name="num1" />

    <label>Number 2</label>
    <input type="number" name="num2" />

    <input type="submit" name="submit">
</form>