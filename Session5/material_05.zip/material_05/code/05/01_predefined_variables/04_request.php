<?php

$name = 'ahmed';
$age = 20;

?>

<a href="recievers/request_reciever.php?name=<?= $name ?>&age=<?= $age ?>">Send to request receiver</a>

<br>
<br>
<br>
<br>
<br>

<form action="recievers/request_reciever.php" method="POST">
    <label>Name</label>
    <input type="text" name="name" />

    <label>Age</label>
    <input type="number" name="age" />

    <input type="submit">
</form>