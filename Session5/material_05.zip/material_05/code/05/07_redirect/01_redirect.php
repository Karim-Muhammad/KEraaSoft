<?php

header("Location: another.php");
exit;


setcookie('name', 'hello', time() + 60 * 60, '/');