<?php

echo "Hello from another.php file";