<?php

// echo date('Y-m-d h:i:s');

// $time = mktime(12, 12, 12, 1, 25, 2021);

// echo date('Y-m-d h:i:s', $time);

// $time = strtotime('+4 weeks');
// $time = strtotime('tomorrow');
echo date('Y-m-d h:i:s', $time);