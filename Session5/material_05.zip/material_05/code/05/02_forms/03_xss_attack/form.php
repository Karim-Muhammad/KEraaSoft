<?php

?>

<!-- Vulnerable form -->


<!-- Not Vulnerable form -->
<form action="<?php echo htmlentities($_SERVER['PHP_SELF']) ?>">
    <input type="text" name="name">
    <input type="submit">
</form>