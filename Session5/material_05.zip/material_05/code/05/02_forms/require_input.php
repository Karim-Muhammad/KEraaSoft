<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST') {

        $name = trim($_POST['name']);

        if(empty($name)) {
            echo "Please submit your name is required!";
        } else {
            echo "You have submitted the input name";
            
        }
    }
?>

<!-- Vulnerable form -->


<!-- Not Vulnerable form -->
<form action="<?php echo htmlentities($_SERVER['PHP_SELF']) ?>" method="POST">
    <input type="text" name="name">
    <input type="submit">
</form>