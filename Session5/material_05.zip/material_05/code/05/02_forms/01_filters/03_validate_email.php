<?php

$var = "ali@gmail.com";

if(filter_var($var, FILTER_VALIDATE_EMAIL)) {

    echo "The variable contains valid email";


} else {


    echo "The variable contains some thing else";
}