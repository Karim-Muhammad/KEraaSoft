<?php

$var = "<h1>hello</h1>";

echo filter_var($var, FILTER_SANITIZE_STRING);