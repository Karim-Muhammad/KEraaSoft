<?php

echo "<pre>";
    print_r(filter_list());
echo "</pre>";