<?php

$var = "100";

if(filter_var($var, FILTER_VALIDATE_INT)) {

    echo "The variable contains integer";


} else {


    echo "The variable contains some thing else";
}