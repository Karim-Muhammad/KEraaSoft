<?php

$var = "<script>alert('D7kt 3alek ya ahbal')</script>";

$var = htmlspecialchars($var);

$var = htmlentities($var);

$var = stripslashes($var);

$var = trim($var);