<?php

include_once "../folder_01/parent/hamada.php";
// include_once "../folder_01/parent/included.php";
// include_once "../folder_01/parent/included.php";

displaySentence();

echo "<br>";

echo "some code after function";