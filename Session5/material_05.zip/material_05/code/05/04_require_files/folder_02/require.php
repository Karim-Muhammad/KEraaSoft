<?php

require_once "../folder_01/parent/hamada.php";
// require_once "../folder_01/parent/required.php";
// require_once "../folder_01/parent/required.php";

displaySentence();

echo "<br>";

echo "some code after function";