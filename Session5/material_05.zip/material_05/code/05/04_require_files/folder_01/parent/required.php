<?php

function displaySentence()
{
    echo "Hello from course";

    echo "<br>";

    echo "We're in the fifth session";
}