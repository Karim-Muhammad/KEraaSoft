<?php

// $content = file_get_contents('newFile2.txt');

$data = json_decode(file_get_contents('data.json'), true);

foreach($data as $user) {
    echo $user['name'];
    echo "<br>";
}

echo "<pre>";
    print_r($data);
echo "</pre>";
