<?php

// file_put_contents('newFile2.txt', 'hello from file_put_content()');


$data = [
    [
        'name' => 'morshedy',
        'email' => 'morshedt@elnargesy.com',
    ],
    [
        'name' => 'mohamed',
        'email' => 'mohamed@elzah2an.com'
    ],
];

file_put_contents('data.json', json_encode($data));