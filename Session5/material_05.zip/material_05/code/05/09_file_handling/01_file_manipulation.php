<?php

// echo readfile('words.txt');

$file = fopen('words.txt', 'a+');

// echo fread($file, filesize('words.txt'));

// echo fgets($file);
// echo "<br>";
// echo fgets($file);

// while(!feof($file)) {
//     echo fgets($file);
//     echo "<br>";
// }

// while(!feof($file)) {
//     echo fgetc($file);
//     echo "<br>";
// }

fclose($file);

$file = fopen('newFile.txt', 'a+');

    fwrite($file, 'Faw2 m3ana ya3ml morshedy');

fclose($file);

$lines = file('words.txt');

foreach($lines as $line) {

    echo $line;
    echo "<br>";
}