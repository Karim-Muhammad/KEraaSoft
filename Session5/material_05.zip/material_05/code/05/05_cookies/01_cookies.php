<?php

// To create a cookie
setcookie('theme_color', 'dark', time() + 30 * 24 * 60 * 60, '/');

// How to retrieve cookie value
// echo $_COOKIE['theme_color'];

// How to modify a cookie
setcookie('theme_color', 'light', time() + 30 * 24 * 60 * 60, '/');
// $_COOKIE['theme_color'] = 'light';   // wrong way

// if(isset($_COOKIE['theme_color'])) {
//     echo $_COOKIE['theme_color'];
// }

// if(isset($_COOKIE['hamada'])) {
//     echo $_COOKIE['hamada'];
// }

// echo $_COOKIE['hamada'];

// How to delete a cookie
setcookie('theme_color', 'dark', time() - 30 * 24 * 60 * 60, '/');
// unset($_COOKIE['theme_color']); // wrong way

echo $_COOKIE['theme_color'];
