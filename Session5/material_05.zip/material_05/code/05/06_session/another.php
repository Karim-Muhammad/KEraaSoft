<?php

session_start();



$_SESSION['password'] = 'mohamed el hacker';

// How to retrieve a session value
echo $_SESSION['password'];

