<?php

session_start();




// how to define a session
$_SESSION['password'] = '123456789';
$_SESSION['name'] = 'elmorshedy';

unset($_SESSION['name']);   // delete a specific key

$_SESSION = [];
session_unset();
session_destroy();



echo "<pre>";
    print_r($_SESSION);
echo "</pre>";


// echo $_SESSION['password'];

// echo session_id();


